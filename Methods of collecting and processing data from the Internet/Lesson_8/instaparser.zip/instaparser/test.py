l1 = [1,2,3,4]
l2 = l1.copy()
l2.append(5)
print(l1)