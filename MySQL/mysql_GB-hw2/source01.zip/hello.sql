SELECT "Hello world!";
